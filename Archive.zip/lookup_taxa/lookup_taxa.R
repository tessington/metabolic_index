source("lookup_taxa/lookup_taxa_helper.R")

taxa.name <- "Gadus"

lookup_taxa(taxa.name)
  